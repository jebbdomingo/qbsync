<?php

QuickBooks_Loader::load('/QuickBooks/IPP/Object.php');

class QuickBooks_IPP_Object_Estimate extends QuickBooks_IPP_Object
{
	
}
