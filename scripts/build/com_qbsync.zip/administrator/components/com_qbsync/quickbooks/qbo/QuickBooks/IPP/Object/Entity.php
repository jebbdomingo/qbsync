<?php

QuickBooks_Loader::load('/QuickBooks/IPP/Object.php');

class QuickBooks_IPP_Object_Entity extends QuickBooks_IPP_Object
{
	
}
